package fileUtility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class AccessBrowserAndUrl {

	public String accessData(String key) throws  IOException {
		// TODO Auto-generated method stub
		Properties prop=new Properties();
		FileInputStream fis=new FileInputStream(".\\src\\test\\resources\\RequiredData.properties");
		prop.load(fis);
		String br=prop.getProperty(key);
		return br;
		
	}
}
		
		
		
	

	