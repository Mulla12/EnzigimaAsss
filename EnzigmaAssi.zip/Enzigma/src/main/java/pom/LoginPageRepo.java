package pom;

public class LoginPageRepo {

}
