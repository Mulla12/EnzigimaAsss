package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ForgotPageRepo {
	public ForgotPageRepo(WebDriver driver)
	{
		
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="/a[text()='Forgot Password?']")
	private WebElement forgotPasswordLink;
	public WebElement forgotPasswordLink()
	{
		return forgotPasswordLink;
	}
	
	@FindBy(xpath="(//input[@name='username'])[2]")
	private WebElement emailTextField;
	public WebElement emailTextField()
	{
		return emailTextField;
		
	}
	
	@FindBy(css="div[title='Proceed']")
	private WebElement proceedBtn;
	public WebElement proceedBtn()
	{
		return proceedBtn;
	}
	
	@FindBy(xpath="//h2[text()='Verification code sent successfully']")
	
	private WebElement verificationSuccessfullMsg;
	public WebElement verificationSuccessfullMsg()
	{
		return verificationSuccessfullMsg;
	}
	
	@FindBy(xpath="//h2[text()='Please enter a valid email']")
	private WebElement invalidEmailmsg;
	public WebElement invalidEmailmsg()
	{ 
		return invalidEmailmsg;
	}
	
	@FindBy(xpath="//h2[text()='Please enter email']")
	private WebElement blanEmailMsg;
	public WebElement blanEmailMsg()
	{ 
		return blanEmailMsg;
	}
	
 

}
