package baseClass;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import fileUtility.AccessBrowserAndUrl;

public class BaseClass {
	public static WebDriver driver;
	public static AccessBrowserAndUrl browser;
	
	@BeforeSuite
	public void beforeSuite()
	{
		System.out.println("BeforeSuite");
	}
	
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("BeforeTest");
	}
	@AfterTest
	public void afterTest()
	{
		System.out.println("AfterTest");
	}
	
	@BeforeClass
		
	public void preCondition() throws IOException
	{
		browser = new AccessBrowserAndUrl();
		String br =browser.accessData("Browser");

		if(br.equalsIgnoreCase("chrome"))
		{
			driver = new ChromeDriver();
		}
		
		else if(br.equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
		}
		
		else 
		{
			driver = new ChromeDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		String url=browser.accessData("url");
		driver.get(url);
	}
	@BeforeMethod
	public static void beforeMethod() throws IOException
	{
		System.out.println("BeforeMethod");
	}
	
	@AfterMethod
	public static void afterMethod()
	{
		System.out.println("AfterMethod");
	}
	
	@AfterClass
	public static void postCondition()
	{
	//	driver.quit();
	}
	
	@AfterSuite
	public void afterSuite()
	{
		System.out.println("AfterSuite");
	}
	

}
