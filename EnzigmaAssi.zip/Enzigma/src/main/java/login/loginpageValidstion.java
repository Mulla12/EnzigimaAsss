package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class loginpageValidstion {

	    public static void main(String[] args) {
	        // Set the ChromeDriver path
	        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

	        // Initialize the WebDriver
	        WebDriver driver = new ChromeDriver();

	        try {
	            // Navigate to the login page
	            driver.get("https://www.nokodr.com/login");
	            
	            // Maximize the browser window
	            driver.manage().window().maximize();

	            // Locate input fields
	            WebElement usernameField = driver.findElement(By.id("username")); // Replace with the actual ID or locator
	            WebElement passwordField = driver.findElement(By.id("password")); // Replace with the actual ID or locator
	            WebElement loginButton = driver.findElement(By.id("loginButton")); // Replace with the actual ID or locator

	            // 1. Mandatory field validation
	            loginButton.click();
	            String mandatoryError = driver.findElement(By.id("error")).getText(); // Replace with actual error element ID
	            System.out.println("Mandatory Field Error: " + mandatoryError);

	            // 2. Validate password length/format
	            usernameField.sendKeys("testuser");
	            passwordField.sendKeys("short");
	            loginButton.click();
	            String passwordError = driver.findElement(By.id("error")).getText(); // Replace with actual error element ID
	            System.out.println("Password Format Error: " + passwordError);

	            // 3. Valid credentials test
	            usernameField.clear();
	            passwordField.clear();
	            usernameField.sendKeys("validuser");
	            passwordField.sendKeys("ValidPassword123!");
	            loginButton.click();
	            boolean isDashboard = driver.getCurrentUrl().contains("dashboard");
	            System.out.println("Login with valid credentials: " + (isDashboard ? "Success" : "Failure"));

	            // 4. Invalid credentials tests
	            // a. Incorrect username/password
	            usernameField.clear();
	            passwordField.clear();
	            usernameField.sendKeys("wronguser");
	            passwordField.sendKeys("wrongpassword");
	            loginButton.click();
	            String invalidCredError = driver.findElement(By.id("error")).getText(); // Replace with actual error element ID
	            System.out.println("Invalid Credentials Error: " + invalidCredError);

	            // b. Blank fields
	            usernameField.clear();
	            passwordField.clear();
	            loginButton.click();
	            String blankFieldError = driver.findElement(By.id("error")).getText(); // Replace with actual error element ID
	            System.out.println("Blank Fields Error: " + blankFieldError);

	            // c. Special characters
	            usernameField.clear();
	            passwordField.clear();
	            usernameField.sendKeys("invalid@user");
	            passwordField.sendKeys("invalid#password");
	            loginButton.click();
	            String specialCharError = driver.findElement(By.id("error")).getText(); // Replace with actual error element ID
	            System.out.println("Special Character Error: " + specialCharError);

	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            // Close the browser
	            driver.quit();
	        }
	    }
	}


}
