package ForgotPasswordValidation;

import java.time.Duration;

import org.testng.annotations.Test;

import baseClass.BaseClass;
import pom.ForgotPageRepo;

public class ForInvalidEmailFormate extends BaseClass {
	
	@Test
	public void script3() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ForgotPageRepo fp=new ForgotPageRepo(driver);
		fp.forgotPasswordLink().click();
		Thread.sleep(2000);
		fp.emailTextField().sendKeys("abs@gmail.com");
		Thread.sleep(2000);
		fp.proceedBtn().click();
		if(fp.invalidEmailmsg().isDisplayed())
		{
			System.out.println("invalid email id formate");
		}
		Thread.sleep(2000);
		driver.close();
	}
	

}
