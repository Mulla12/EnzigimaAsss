package ForgotPasswordValidation;

import java.time.Duration;

import org.testng.annotations.Test;

import baseClass.BaseClass;

public class ForNonRegisterEmail  extends BaseClass{
	@Test
	public void script2() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		
		
		
		
		
	}
	

}
