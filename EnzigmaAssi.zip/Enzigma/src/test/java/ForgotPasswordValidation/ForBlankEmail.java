package ForgotPasswordValidation;

import java.time.Duration;

import org.testng.annotations.Test;

import baseClass.BaseClass;
import pom.ForgotPageRepo;

public class ForBlankEmail extends BaseClass {
	
		
	@Test
	public void script() throws InterruptedException{
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		ForgotPageRepo fp=new ForgotPageRepo(driver);
		
		fp.forgotPasswordLink().click();
		Thread.sleep(2000);
		fp.emailTextField().sendKeys("sumaiyamulla250@gmail.com");
		Thread.sleep(2000);
		fp.proceedBtn().click();
		if(fp.blanEmailMsg().isDisplayed())
		{
			System.out.println("blank mail id");
		}
		Thread.sleep(2000);
		driver.close();
	}
	}


