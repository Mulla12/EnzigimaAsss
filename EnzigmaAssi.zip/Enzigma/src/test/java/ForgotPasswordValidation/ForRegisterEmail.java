package ForgotPasswordValidation;

public class ForRegisterEmail {

}
