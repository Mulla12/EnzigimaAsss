package basicScript;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class basicNoloder {
	public static void main(String[] args) {
        // Set up WebDriver and specify the path to ChromeDriver
        System.setProperty("webdriver.chrome.driver", "path_to_chromedriver");

        // Initialize ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            // Open the browser and navigate to the noKodr platform
            String url = "https://app-staging.nokodr.com/";
            driver.get(url);

            // Print the title of the page to verify navigation
            System.out.println("Page Title: " + driver.getTitle());

            // Add a small wait to observe the browser (optional)
            Thread.sleep(3000);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}


