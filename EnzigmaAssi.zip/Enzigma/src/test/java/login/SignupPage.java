package login;

public interface SignupPage {

}
