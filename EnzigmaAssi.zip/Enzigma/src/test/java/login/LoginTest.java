package login;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Test;

public class LoginTest {
	
		WebDriver driver;
	    SignupPage loginPage;

	    @org.testng.annotations.Test(dataProvider = "loginData")
	    public void testSignup(String name, String email, String password, String confirmPassword, String expectedResult) {
	        // Initialize WebDriver (make sure to set up WebDriverManager or manually set path)
	        driver = new ChromeDriver();
	        driver.get("https://your-login-page-url.com");

	        // Initialize loginPage object
	        LoginPageValidation = new LoginPageValidation(driver);

	        // Fill out the form
	        
	        LoginPageVaLoginPageValidationlidatio.enterName(name);
	        LoginPageValidatio.enterEmail(email);
	        LoginPageValidatio.enterPassword(password);
	        LoginPageValidatio.enterConfirmPassword(confirmPassword);

	        // Submit the form
	        LoginPageValidatio.clickSubmit();

	        // Validation
	        if (expectedResult.equals("success")) {
	            Assert.assertEquals(LoginPageValidatio.getSuccessMessage(), "Account created successfully!");
	        } else {
	            Assert.assertTrue(LoginPageValidatio.getErrorMessage().contains("error"));
	        }

	        // Close the browser
	        driver.quit();
	    }
	    @DataProvider(name = "loginData")
	    public Object[][] getSignupData() throws IOException {
	        FileInputStream file = new FileInputStream(new File("src/resources/testdata/login_data.xlsx"));
	        Workbook workbook = new XSSFWorkbook(file);
	        Sheet sheet = workbook.getSheetAt(0);
	        int rowCount = sheet.getPhysicalNumberOfRows();
	        int colCount = sheet.getRow(0).getPhysicalNumberOfCells();

	        Object[][] data = new Object[rowCount - 1][colCount]; // Excluding header row

	        for (int i = 1; i < rowCount; i++) {
	            for (int j = 0; j < colCount; j++) {
	                data[i - 1][j] = sheet.getRow(i).getCell(j).getStringCellValue();
	            }
	        }
	        workbook.close();
	        return data;
	    }


}
